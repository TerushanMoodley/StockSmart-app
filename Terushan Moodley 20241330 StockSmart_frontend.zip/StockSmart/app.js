/* ============================================================
   StockSmart — front-end logic (vanilla JS)
   State kept in memory; mirrored to localStorage when available.
   Screens: Dashboard · Inventory · Sales
   ============================================================ */

(function () {
  "use strict";

  /* ---------- Sample data (spaza shop) ---------- */
  const SEED_PRODUCTS = [
    { id: p(), name: "White Bread 700g",      category: "Bakery",     price: 18.50, qty: 12, reorder: 6 },
    { id: p(), name: "Full Cream Milk 1L",    category: "Dairy",      price: 22.00, qty: 3,  reorder: 6 },
    { id: p(), name: "White Sugar 2.5kg",     category: "Grocery",    price: 54.90, qty: 20, reorder: 8 },
    { id: p(), name: "Maize Meal 5kg",        category: "Grocery",    price: 69.90, qty: 7,  reorder: 5 },
    { id: p(), name: "Cooking Oil 750ml",     category: "Grocery",    price: 34.90, qty: 0,  reorder: 4 },
    { id: p(), name: "Eggs (6 pack)",         category: "Dairy",      price: 19.90, qty: 9,  reorder: 6 },
    { id: p(), name: "Cold Drink 500ml",      category: "Beverages",  price: 14.00, qty: 24, reorder: 12 },
    { id: p(), name: "Airtime R10",           category: "Airtime",    price: 10.00, qty: 40, reorder: 15 },
    { id: p(), name: "Instant Coffee 100g",   category: "Grocery",    price: 49.90, qty: 5,  reorder: 5 },
    { id: p(), name: "Potato Chips 125g",     category: "Snacks",     price: 16.90, qty: 18, reorder: 10 },
  ];
  function todaySales(products) {
    // a few sample sales already captured "today"
    const find = n => products.find(x => x.name === n);
    return [
      { id: p(), productId: find("White Bread 700g").id,   name: "White Bread 700g",   qty: 2, unit: 18.50, time: hoursAgo(2) },
      { id: p(), productId: find("Cold Drink 500ml").id,   name: "Cold Drink 500ml",   qty: 3, unit: 14.00, time: hoursAgo(1.3) },
      { id: p(), productId: find("Airtime R10").id,        name: "Airtime R10",        qty: 5, unit: 10.00, time: hoursAgo(0.6) },
      { id: p(), productId: find("Eggs (6 pack)").id,      name: "Eggs (6 pack)",      qty: 1, unit: 19.90, time: hoursAgo(0.2) },
    ];
  }

  /* ---------- State ---------- */
  const STORE_KEY = "stocksmart.v1";
  let state = load();

  function freshState() {
    const products = SEED_PRODUCTS.map(x => ({ ...x }));
    return { products, sales: todaySales(products), view: "dashboard" };
  }
  function load() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (raw) {
        const s = JSON.parse(raw);
        if (s && Array.isArray(s.products)) { s.view = "dashboard"; return s; }
      }
    } catch (e) { /* ignore — fall back to seed */ }
    return freshState();
  }
  function save() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify({ products: state.products, sales: state.sales })); }
    catch (e) { /* storage unavailable — in-memory only */ }
  }

  /* ---------- Helpers ---------- */
  function p() { return "id" + Math.random().toString(36).slice(2, 9); }
  function hoursAgo(h) { return Date.now() - h * 3600 * 1000; }
  const rand = { } ;
  const ZAR = new Intl.NumberFormat("en-ZA", { style: "currency", currency: "ZAR" });
  const money = n => ZAR.format(n || 0);
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const el = id => document.getElementById(id);
  function fmtTime(ts) {
    try { return new Date(ts).toLocaleTimeString("en-ZA", { hour: "2-digit", minute: "2-digit" }); }
    catch (e) { return ""; }
  }
  function statusOf(prod) {
    if (prod.qty <= 0) return "crit";
    if (prod.qty <= prod.reorder) return "warn";
    return "ok";
  }
  function statusPill(prod) {
    const s = statusOf(prod);
    const label = s === "crit" ? "Out of stock" : s === "warn" ? "Low" : "In stock";
    return `<span class="pill pill--${s}">${label}</span>`;
  }
  const lowStock = () => state.products.filter(x => x.qty <= x.reorder);

  /* ---------- SVG icons ---------- */
  const I = {
    dash:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>',
    box:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/></svg>',
    cart:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>',
    alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>',
    rand:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="2" x2="12" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',
    plus:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5v14"/></svg>',
    search:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>',
    edit:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>',
    sun:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
    moon:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>',
    bag:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>',
    report:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><rect x="7" y="11" width="3" height="6"/><rect x="12" y="7" width="3" height="10"/><rect x="17" y="13" width="3" height="4"/></svg>',
  };

  /* ============================================================
     Rendering
     ============================================================ */
  function render() {
    renderNav();
    const main = el("main");
    if (state.view === "dashboard")      main.innerHTML = viewDashboard();
    else if (state.view === "inventory") main.innerHTML = viewInventory();
    else if (state.view === "sales")     main.innerHTML = viewSales();
    else if (state.view === "reports")   main.innerHTML = viewReports();
    bindViewEvents();
  }

  function renderNav() {
    document.querySelectorAll(".nav__item").forEach(btn => {
      btn.classList.toggle("is-active", btn.dataset.view === state.view);
    });
    const low = lowStock().length;
    const badge = el("navBadge");
    badge.textContent = low;
    badge.hidden = low === 0;
  }

  /* ---------- Dashboard ---------- */
  function viewDashboard() {
    const totalItems = state.products.length;
    const low = lowStock();
    const salesToday = state.sales.reduce((s, x) => s + x.qty * x.unit, 0);
    const txToday = state.sales.length;
    const stockValue = state.products.reduce((s, x) => s + x.qty * x.price, 0);

    const alertBlock = low.length ? `
      <div class="alert" role="status">
        ${I.alert}
        <div class="alert__body">
          <b>${low.length} item${low.length > 1 ? "s" : ""} need attention.</b>
          Reorder these before they run out:
          <ul class="alert__list">
            ${low.map(x => `<li class="alert__chip">${esc(x.name)} · ${x.qty} left</li>`).join("")}
          </ul>
        </div>
      </div>` : `
      <div class="alert" style="background:var(--ok-bg);border-color:color-mix(in srgb,var(--ok) 32%,transparent)">
        ${I.check.replace('stroke-width="2.5"','stroke-width="2.5" style="color:var(--ok)"')}
        <div class="alert__body"><b style="color:var(--ok)">All stock is healthy.</b> No items are at or below their reorder level.</div>
      </div>`;

    const recent = state.sales.slice().sort((a, b) => b.time - a.time).slice(0, 5);

    return `
    <section class="view">
      <div class="view__head">
        <div>
          <h1>Dashboard</h1>
          <p>Live overview for today — ${esc(new Date().toLocaleDateString("en-ZA", { weekday: "long", day: "numeric", month: "long" }))}</p>
        </div>
        <button class="btn btn--primary" data-go="sales">${I.cart} Record a sale</button>
      </div>

      <div class="kpis">
        ${kpi(I.box,  "primary", "Items tracked", totalItems)}
        ${kpi(I.alert, low.length ? "warn" : "ok", "Low / out of stock", low.length)}
        ${kpi(I.rand, "ok", "Sales today", money(salesToday))}
        ${kpi(I.bag,  "primary", "Stock on hand (value)", money(stockValue))}
      </div>

      ${alertBlock}

      <div class="card">
        <div class="card__head">
          <h2>Recent sales</h2>
          <button class="btn btn--subtle" data-go="sales">View all</button>
        </div>
        <div class="card__body">
          <div class="table-wrap">
            <table class="data">
              <thead><tr><th>Item</th><th class="num">Qty</th><th class="num">Line total</th><th class="num">Time</th></tr></thead>
              <tbody>
                ${recent.length ? recent.map(s => `
                  <tr>
                    <td class="item-name">${esc(s.name)}</td>
                    <td class="num">${s.qty}</td>
                    <td class="num">${money(s.qty * s.unit)}</td>
                    <td class="num" style="color:var(--muted)">${fmtTime(s.time)}</td>
                  </tr>`).join("") : `<tr><td colspan="4"><div class="empty">No sales recorded yet today.</div></td></tr>`}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>`;
  }
  function kpi(icon, tone, label, value) {
    const toneCls = tone === "warn" ? "is-warn" : tone === "ok" ? "is-ok" : "";
    return `
    <div class="kpi">
      <div class="kpi__top">
        <span class="kpi__label">${label}</span>
        <span class="kpi__icon ${toneCls}">${icon}</span>
      </div>
      <span class="kpi__value tnum">${value}</span>
    </div>`;
  }

  /* ---------- Inventory ---------- */
  let invSearch = "";
  let invFilter = "all"; // all | low | out
  function invRows() {
    const q = invSearch.trim().toLowerCase();
    return state.products
      .filter(x => !q || x.name.toLowerCase().includes(q) || x.category.toLowerCase().includes(q))
      .filter(x => invFilter === "all" || (invFilter === "low" && x.qty <= x.reorder) || (invFilter === "out" && x.qty <= 0))
      .sort((a, b) => statusRank(a) - statusRank(b) || a.name.localeCompare(b.name));
  }
  function invEmptyMsg() {
    if (invSearch.trim()) return `No items match “${esc(invSearch)}”.`;
    if (invFilter === "low") return "No items are low on stock. ";
    if (invFilter === "out") return "Nothing is out of stock. ";
    return "No items yet. Add your first stock item.";
  }
  function viewInventory() {
    const rows = invRows();
    const chip = (key, label) => `<button class="chip-btn ${invFilter === key ? "is-active" : ""}" data-filter="${key}">${label}</button>`;

    return `
    <section class="view">
      <div class="view__head">
        <div>
          <h1>Inventory</h1>
          <p>${state.products.length} products · ${lowStock().length} need reordering</p>
        </div>
        <button class="btn btn--primary" id="addBtn">${I.plus} Add stock item</button>
      </div>

      <div class="card">
        <div class="card__head">
          <div class="search">${I.search}<input id="invSearch" type="search" placeholder="Search item or category" value="${esc(invSearch)}" aria-label="Search inventory"></div>
          <div class="filters" role="group" aria-label="Filter inventory">
            ${chip("all", "All")}${chip("low", "Low stock")}${chip("out", "Out of stock")}
          </div>
        </div>
        <div class="card__body">
          <div class="table-wrap">
            <table class="data">
              <thead>
                <tr><th>Item</th><th class="num">Price</th><th class="num">In stock</th><th class="num">Reorder at</th><th>Status</th><th></th></tr>
              </thead>
              <tbody>
                ${rows.length ? rows.map(invRow).join("") : `<tr><td colspan="6"><div class="empty">${invEmptyMsg()}</div></td></tr>`}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>`;
  }
  function statusRank(p) { const s = statusOf(p); return s === "crit" ? 0 : s === "warn" ? 1 : 2; }
  function invRow(x) {
    return `
    <tr>
      <td><div class="item-name">${esc(x.name)}</div><div class="item-cat">${esc(x.category)}</div></td>
      <td class="num">${money(x.price)}</td>
      <td class="num"><b>${x.qty}</b></td>
      <td class="num" style="color:var(--muted)">${x.reorder}</td>
      <td>${statusPill(x)}</td>
      <td>
        <div class="row-actions">
          <button class="icon-btn" title="Add stock (restock)" data-restock="${x.id}">${I.plus}</button>
          <button class="icon-btn" title="Edit" data-edit="${x.id}">${I.edit}</button>
          <button class="btn btn--danger" title="Delete" data-del="${x.id}">${I.trash}</button>
        </div>
      </td>
    </tr>`;
  }

  /* ---------- Sales ---------- */
  function viewSales() {
    const sales = state.sales.slice().sort((a, b) => b.time - a.time);
    const total = sales.reduce((s, x) => s + x.qty * x.unit, 0);
    const units = sales.reduce((s, x) => s + x.qty, 0);

    return `
    <section class="view">
      <div class="view__head">
        <div><h1>Sales</h1><p>Record a sale and review today's takings</p></div>
      </div>

      <div class="kpis" style="grid-template-columns:repeat(3,1fr)">
        ${kpi(I.rand, "ok", "Takings today", money(total))}
        ${kpi(I.cart, "primary", "Transactions", sales.length)}
        ${kpi(I.box, "primary", "Units sold", units)}
      </div>

      <div class="card">
        <div class="card__head"><h2>Record a sale</h2></div>
        <div class="card__body" style="padding:18px">
          <form id="saleForm" style="display:grid;grid-template-columns:2fr 1fr auto;gap:12px;align-items:end">
            <div class="field">
              <label for="saleItem">Item</label>
              <select id="saleItem" required>
                <option value="" disabled selected>Choose an item…</option>
                ${state.products.map(x => `<option value="${x.id}" ${x.qty <= 0 ? "disabled" : ""}>${esc(x.name)}${x.qty <= 0 ? " — out of stock" : ` (${x.qty} in stock)`}</option>`).join("")}
              </select>
            </div>
            <div class="field">
              <label for="saleQty">Quantity</label>
              <input id="saleQty" type="number" min="1" step="1" value="1" required>
            </div>
            <button class="btn btn--primary" type="submit" style="height:44px">${I.check} Confirm sale</button>
            <div id="saleHint" class="hint" style="grid-column:1/-1;color:var(--muted);font-size:12.5px;min-height:16px"></div>
          </form>
        </div>
      </div>

      <div class="card">
        <div class="card__head"><h2>Today's sales</h2></div>
        <div class="card__body">
          <div class="table-wrap">
            <table class="data">
              <thead><tr><th>Item</th><th class="num">Qty</th><th class="num">Unit</th><th class="num">Line total</th><th class="num">Time</th></tr></thead>
              <tbody>
                ${sales.length ? sales.map(s => `
                  <tr>
                    <td class="item-name">${esc(s.name)}</td>
                    <td class="num">${s.qty}</td>
                    <td class="num">${money(s.unit)}</td>
                    <td class="num"><b>${money(s.qty * s.unit)}</b></td>
                    <td class="num" style="color:var(--muted)">${fmtTime(s.time)}</td>
                  </tr>`).join("") : `<tr><td colspan="5"><div class="empty">No sales yet. Record your first one above.</div></td></tr>`}
              </tbody>
              ${sales.length ? `<tfoot><tr style="border-top:2px solid var(--border)"><td colspan="3" style="font-weight:700">Total</td><td class="num" style="font-weight:800">${money(total)}</td><td></td></tr></tfoot>` : ""}
            </table>
          </div>
        </div>
      </div>
    </section>`;
  }

  /* ---------- Reports ---------- */
  function viewReports() {
    // Sales report — aggregate today's sales by item
    const byItem = {};
    state.sales.forEach(s => {
      const k = s.name;
      if (!byItem[k]) byItem[k] = { name: k, qty: 0, revenue: 0 };
      byItem[k].qty += s.qty;
      byItem[k].revenue += s.qty * s.unit;
    });
    const salesRows = Object.values(byItem).sort((a, b) => b.revenue - a.revenue);
    const takings = salesRows.reduce((t, x) => t + x.revenue, 0);
    const units = salesRows.reduce((t, x) => t + x.qty, 0);
    const maxRev = Math.max(1, ...salesRows.map(x => x.revenue));

    // Stock report — value by category + reorder list
    const byCat = {};
    state.products.forEach(pd => {
      const k = pd.category || "Uncategorised";
      byCat[k] = (byCat[k] || 0) + pd.qty * pd.price;
    });
    const catRows = Object.entries(byCat).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
    const maxCat = Math.max(1, ...catRows.map(x => x.value));
    const stockValue = catRows.reduce((t, x) => t + x.value, 0);
    const reorder = lowStock().slice().sort((a, b) => statusRank(a) - statusRank(b));

    const bar = (label, val, display, max) => `
      <div class="bar">
        <span class="bar__label" title="${esc(label)}">${esc(label)}</span>
        <span class="bar__track"><span class="bar__fill" style="width:${Math.max(3, Math.round(val / max * 100))}%"></span></span>
        <span class="bar__val tnum">${display}</span>
      </div>`;

    return `
    <section class="view">
      <div class="view__head">
        <div><h1>Reports</h1><p>Sales and stock summary for ${esc(new Date().toLocaleDateString("en-ZA", { day: "numeric", month: "long" }))}</p></div>
      </div>

      <div class="card">
        <div class="card__head"><h2>Sales report — today</h2></div>
        <div class="card__body" style="padding:14px 16px">
          <div class="kpis" style="grid-template-columns:repeat(3,1fr);margin-bottom:14px">
            ${kpi(I.rand, "ok", "Takings", money(takings))}
            ${kpi(I.cart, "primary", "Transactions", state.sales.length)}
            ${kpi(I.box, "primary", "Units sold", units)}
          </div>
          <div style="font-size:12px;letter-spacing:.05em;text-transform:uppercase;color:var(--muted);font-weight:700;margin:4px 2px 10px">Takings by item</div>
          <div class="barlist">
            ${salesRows.length ? salesRows.map(x => bar(`${x.name} · ${x.qty}×`, x.revenue, money(x.revenue), maxRev)).join("") : `<div class="empty">No sales recorded today.</div>`}
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card__head"><h2>Stock report</h2></div>
        <div class="card__body" style="padding:14px 16px">
          <div class="kpis" style="grid-template-columns:repeat(3,1fr);margin-bottom:14px">
            ${kpi(I.bag, "primary", "Stock on hand (value)", money(stockValue))}
            ${kpi(I.box, "primary", "Items tracked", state.products.length)}
            ${kpi(I.alert, reorder.length ? "warn" : "ok", "Need reordering", reorder.length)}
          </div>
          <div style="font-size:12px;letter-spacing:.05em;text-transform:uppercase;color:var(--muted);font-weight:700;margin:4px 2px 10px">Stock value by category</div>
          <div class="barlist">
            ${catRows.map(x => bar(x.name, x.value, money(x.value), maxCat)).join("")}
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card__head"><h2>Reorder list</h2></div>
        <div class="card__body">
          <div class="table-wrap">
            <table class="data">
              <thead><tr><th>Item</th><th class="num">In stock</th><th class="num">Reorder at</th><th>Status</th></tr></thead>
              <tbody>
                ${reorder.length ? reorder.map(x => `
                  <tr>
                    <td><div class="item-name">${esc(x.name)}</div><div class="item-cat">${esc(x.category)}</div></td>
                    <td class="num"><b>${x.qty}</b></td>
                    <td class="num" style="color:var(--muted)">${x.reorder}</td>
                    <td>${statusPill(x)}</td>
                  </tr>`).join("") : `<tr><td colspan="4"><div class="empty">Nothing needs reordering right now.</div></td></tr>`}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>`;
  }

  /* ============================================================
     Events
     ============================================================ */
  function bindViewEvents() {
    document.querySelectorAll("[data-go]").forEach(b => b.addEventListener("click", () => go(b.dataset.go)));

    if (state.view === "inventory") {
      el("addBtn").addEventListener("click", () => openItemModal(null));
      const s = el("invSearch");
      s.addEventListener("input", () => {
        invSearch = s.value;
        el("main").querySelector(".table-wrap").innerHTML = tableOnly();
        bindRowActions();
      });
      document.querySelectorAll("[data-filter]").forEach(b => b.addEventListener("click", () => { invFilter = b.dataset.filter; render(); }));
      bindRowActions();
    }

    if (state.view === "sales") {
      const form = el("saleForm");
      const sel = el("saleItem"), qty = el("saleQty"), hint = el("saleHint");
      const update = () => {
        const prod = state.products.find(x => x.id === sel.value);
        if (!prod) { hint.textContent = ""; return; }
        const n = Math.max(1, parseInt(qty.value || "1", 10));
        hint.innerHTML = `In stock: <b>${prod.qty}</b> · Unit ${money(prod.price)} · Line total <b>${money(n * prod.price)}</b>`;
      };
      sel.addEventListener("change", update);
      qty.addEventListener("input", update);
      form.addEventListener("submit", e => { e.preventDefault(); recordSale(sel.value, qty.value); });
    }
  }
  function tableOnly() {
    const rows = invRows();
    return `<table class="data"><thead><tr><th>Item</th><th class="num">Price</th><th class="num">In stock</th><th class="num">Reorder at</th><th>Status</th><th></th></tr></thead><tbody>${rows.length ? rows.map(invRow).join("") : `<tr><td colspan="6"><div class="empty">${invEmptyMsg()}</div></td></tr>`}</tbody></table>`;
  }
  function bindRowActions() {
    document.querySelectorAll("[data-restock]").forEach(b => b.addEventListener("click", () => openRestockModal(b.dataset.restock)));
    document.querySelectorAll("[data-edit]").forEach(b => b.addEventListener("click", () => openItemModal(b.dataset.edit)));
    document.querySelectorAll("[data-del]").forEach(b => b.addEventListener("click", () => confirmDelete(b.dataset.del)));
  }

  function go(view) {
    state.view = view;
    render();
    el("main").scrollTo?.(0, 0);
    window.scrollTo(0, 0);
  }

  /* ---------- Record sale ---------- */
  function recordSale(productId, qtyRaw) {
    const prod = state.products.find(x => x.id === productId);
    const qty = parseInt(qtyRaw, 10);
    if (!prod) { toast("Choose an item first.", "warn"); return; }
    if (!qty || qty < 1) { toast("Enter a quantity of 1 or more.", "warn"); return; }
    if (qty > prod.qty) { toast(`Only ${prod.qty} of ${prod.name} in stock.`, "warn"); return; }

    prod.qty -= qty;
    state.sales.push({ id: p(), productId: prod.id, name: prod.name, qty, unit: prod.price, time: Date.now() });
    save();
    render();
    toast(`Sale recorded — ${qty} × ${prod.name} (${money(qty * prod.price)})`, "ok");
    if (prod.qty <= prod.reorder) {
      setTimeout(() => toast(`${prod.name} is now low (${prod.qty} left).`, "warn"), 400);
    }
  }

  /* ---------- Add / edit item ---------- */
  function openItemModal(id) {
    const editing = id ? state.products.find(x => x.id === id) : null;
    const v = editing || { name: "", category: "", price: "", qty: "", reorder: "" };
    const host = el("modalHost");
    host.innerHTML = `
    <div class="modal-backdrop" id="backdrop">
      <div class="modal" role="dialog" aria-modal="true" aria-labelledby="mTitle">
        <div class="modal__head">
          <h2 id="mTitle">${editing ? "Edit item" : "Add stock item"}</h2>
          <button class="icon-btn" id="mClose" aria-label="Close">${I.close}</button>
        </div>
        <form id="itemForm">
          <div class="modal__body">
            <div class="field">
              <label for="fName">Item name</label>
              <input id="fName" value="${esc(v.name)}" placeholder="e.g. White Bread 700g" required>
              <span class="err" id="eName" hidden>Please enter a name.</span>
            </div>
            <div class="field">
              <label for="fCat">Category</label>
              <input id="fCat" value="${esc(v.category)}" placeholder="e.g. Bakery" list="catList">
              <datalist id="catList">${[...new Set(state.products.map(x => x.category))].map(c => `<option value="${esc(c)}">`).join("")}</datalist>
            </div>
            <div class="field--row">
              <div class="field">
                <label for="fPrice">Unit price</label>
                <div class="input-prefix"><span>R</span><input id="fPrice" type="number" min="0" step="0.01" value="${v.price}" placeholder="0.00" required></div>
              </div>
              <div class="field">
                <label for="fQty">Quantity in stock</label>
                <input id="fQty" type="number" min="0" step="1" value="${v.qty}" placeholder="0" required>
              </div>
            </div>
            <div class="field">
              <label for="fReorder">Reorder level</label>
              <input id="fReorder" type="number" min="0" step="1" value="${v.reorder}" placeholder="e.g. 6" required>
              <span class="hint">Low-stock alert triggers when quantity reaches this number.</span>
            </div>
          </div>
          <div class="modal__foot">
            <button type="button" class="btn btn--ghost" id="mCancel">Cancel</button>
            <button type="submit" class="btn btn--primary">${editing ? "Save changes" : "Add item"}</button>
          </div>
        </form>
      </div>
    </div>`;

    const close = () => { host.innerHTML = ""; };
    el("mClose").onclick = close;
    el("mCancel").onclick = close;
    el("backdrop").onclick = e => { if (e.target.id === "backdrop") close(); };
    el("fName").focus();

    el("itemForm").addEventListener("submit", e => {
      e.preventDefault();
      const name = el("fName").value.trim();
      if (!name) { el("eName").hidden = false; return; }
      const data = {
        name,
        category: el("fCat").value.trim() || "Uncategorised",
        price: Math.max(0, parseFloat(el("fPrice").value) || 0),
        qty: Math.max(0, parseInt(el("fQty").value, 10) || 0),
        reorder: Math.max(0, parseInt(el("fReorder").value, 10) || 0),
      };
      if (editing) { Object.assign(editing, data); toast("Item updated.", "ok"); }
      else { state.products.push({ id: p(), ...data }); toast(`${data.name} added to inventory.`, "ok"); }
      save(); close(); render();
    });
  }

  /* ---------- Restock (stock intake) ---------- */
  function openRestockModal(id) {
    const prod = state.products.find(x => x.id === id);
    if (!prod) return;
    const host = el("modalHost");
    host.innerHTML = `
    <div class="modal-backdrop" id="backdrop">
      <div class="modal" role="dialog" aria-modal="true" aria-labelledby="rTitle" style="max-width:390px">
        <div class="modal__head"><h2 id="rTitle">Add stock</h2><button class="icon-btn" id="rClose" aria-label="Close">${I.close}</button></div>
        <form id="restockForm">
          <div class="modal__body">
            <div class="stockline"><span>${esc(prod.name)}</span><b>${prod.qty} in stock</b></div>
            <div class="field">
              <label for="rQty">Quantity received</label>
              <input id="rQty" type="number" min="1" step="1" value="1" required>
              <span class="hint">Added to the current stock level (stock intake).</span>
            </div>
          </div>
          <div class="modal__foot">
            <button type="button" class="btn btn--ghost" id="rCancel">Cancel</button>
            <button type="submit" class="btn btn--primary">Add to stock</button>
          </div>
        </form>
      </div>
    </div>`;
    const close = () => { host.innerHTML = ""; };
    el("rClose").onclick = close;
    el("rCancel").onclick = close;
    el("backdrop").onclick = e => { if (e.target.id === "backdrop") close(); };
    el("rQty").focus(); el("rQty").select();
    el("restockForm").addEventListener("submit", e => {
      e.preventDefault();
      const n = Math.max(1, parseInt(el("rQty").value, 10) || 0);
      prod.qty += n;
      save(); close(); render();
      toast(`Added ${n} to ${prod.name} — now ${prod.qty} in stock.`, "ok");
    });
  }

  /* ---------- Delete ---------- */
  function confirmDelete(id) {
    const prod = state.products.find(x => x.id === id);
    if (!prod) return;
    const host = el("modalHost");
    host.innerHTML = `
    <div class="modal-backdrop" id="backdrop">
      <div class="modal" role="dialog" aria-modal="true" style="max-width:380px">
        <div class="modal__head"><h2>Delete item?</h2></div>
        <div class="modal__body"><p style="margin:0;font-size:14px">Remove <b>${esc(prod.name)}</b> from the inventory? This cannot be undone.</p></div>
        <div class="modal__foot">
          <button class="btn btn--ghost" id="dCancel">Cancel</button>
          <button class="btn btn--primary" style="background:var(--crit)" id="dYes">Delete</button>
        </div>
      </div>
    </div>`;
    const close = () => { host.innerHTML = ""; };
    el("dCancel").onclick = close;
    el("backdrop").onclick = e => { if (e.target.id === "backdrop") close(); };
    el("dYes").onclick = () => {
      state.products = state.products.filter(x => x.id !== id);
      save(); close(); render(); toast("Item deleted.", "ok");
    };
  }

  /* ---------- Toast ---------- */
  function toast(msg, kind) {
    const host = el("toasts");
    const t = document.createElement("div");
    t.className = "toast" + (kind ? " toast--" + kind : "");
    t.innerHTML = (kind === "ok" ? I.check : kind === "warn" ? I.alert : I.check) + "<span>" + esc(msg) + "</span>";
    host.appendChild(t);
    setTimeout(() => { t.style.opacity = "0"; t.style.transform = "translateY(8px)"; t.style.transition = "all .3s"; }, 2600);
    setTimeout(() => t.remove(), 3000);
  }

  /* ---------- Theme toggle ---------- */
  function initTheme() {
    const btn = el("themeBtn");
    let saved = null;
    try { saved = localStorage.getItem("stocksmart.theme"); } catch (e) {}
    if (saved) document.documentElement.setAttribute("data-theme", saved);
    paintThemeIcon();
    btn.addEventListener("click", () => {
      const cur = document.documentElement.getAttribute("data-theme");
      const sysDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
      const now = cur ? cur : (sysDark ? "dark" : "light");
      const next = now === "dark" ? "light" : "dark";
      document.documentElement.setAttribute("data-theme", next);
      try { localStorage.setItem("stocksmart.theme", next); } catch (e) {}
      paintThemeIcon();
    });
  }
  function paintThemeIcon() {
    const cur = document.documentElement.getAttribute("data-theme");
    const sysDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
    const dark = cur ? cur === "dark" : sysDark;
    el("themeBtn").innerHTML = dark ? I.sun : I.moon;
  }

  /* ---------- Boot ---------- */
  function boot() {
    // nav icons
    el("navDashIcon").innerHTML = I.dash;
    el("navInvIcon").innerHTML = I.box;
    el("navSalesIcon").innerHTML = I.cart;
    el("navReportsIcon").innerHTML = I.report;
    document.querySelectorAll(".nav__item").forEach(b => b.addEventListener("click", () => go(b.dataset.view)));
    // Press Esc to close any open dialog
    document.addEventListener("keydown", e => {
      if (e.key === "Escape") { const h = el("modalHost"); if (h && h.innerHTML) h.innerHTML = ""; }
    });
    initTheme();
    render();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
