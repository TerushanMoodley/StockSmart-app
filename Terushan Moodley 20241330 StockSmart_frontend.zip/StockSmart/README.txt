StockSmart — Inventory & Sales Tracker (Frontend)
==================================================

A lightweight, responsive front-end for a small shop (spaza shop) to track
stock, record sales, and get low-stock alerts. Built with plain HTML, CSS and
JavaScript — no build step, no installation, no internet connection required
(fonts fall back gracefully if offline).

FILES
-----
  index.html    The page. Open this to run the app.
  styles.css    All styling (navy theme, light + dark mode, responsive layout).
  app.js        All logic (state, screens, record sale, add/edit stock, alerts).

HOW TO RUN
----------
  1. Keep all three files together in the same folder.
  2. Double-click index.html  (it opens in your default web browser).
     — or right-click -> Open with -> your browser of choice.
  That's it. No server needed.

  Tip: for the closest-to-real experience you can run a tiny local server
  instead of opening the file directly (optional):
       Python:  python -m http.server 8000     then visit http://localhost:8000
       Node:    npx serve

WHAT TO TEST
------------
  Dashboard  — KPI tiles, low-stock alert banner, recent sales.
  Inventory  — search, add / edit / delete items, status pills
               (In stock / Low / Out of stock).
  Sales      — record a sale (stock drops, sale is logged, low-stock
               warning fires), today's takings total.
  Theme      — the sun/moon button (top-right) toggles light / dark.
  Mobile     — resize the window narrow; the side menu becomes a bottom bar.

NOTES
-----
  • It opens with sample spaza-shop data (bread, milk, maize meal, airtime,
    cold drinks, etc.) and a few sales already logged for "today", so every
    screen has something to look at.
  • Data is stored in your browser only (in-memory, with a localStorage cache),
    so it is per-device and resets if you clear site data. This is the
    frontend-only stage. The next step is connecting it to a hosted database
    (Firebase / Supabase) so stock and sales persist and sync across devices,
    which also enables the owner login and the blue-green deployment.
  • To reset back to the sample data: open the browser console (F12) and run
        localStorage.removeItem("stocksmart.v1")
    then refresh.

Version: Frontend v1 — 19 October 2026
